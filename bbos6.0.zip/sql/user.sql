
################################# custom subsets section
-- place the sql to add game or atbat subsets here
-- for example.
-- insert into mlb.gamesubset gs 
-- select g.gameID, g.season, 'TuesdayGames' as setName, 'ByDaysOfTheWeeek' subset
--   from mlb.games g
--  where DAY(g.gameDate) = 3

 
################################# sql section
-- place the sql you would like run after each load automaticly here

