This is Chadwick, a library and toolset for baseball play-by-play and statistics.

Chadwick is Open Source software.  The library (src/cwlib) is distributed under the GNU Lesser GPL, and tools (src/cwtools) are distributed under the GNU GPL.

For more information about the Chadwick project, please visit the website at http://chadwick.sourceforge.net.