from bbos.db.db import DB
        
def main():
    DB();

if __name__ == '__main__': 
    main()
    
